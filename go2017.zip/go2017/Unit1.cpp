//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#include <iostream>
#include <fstream>
#include <cstdio>

using namespace std;

int main(int argc, char* argv[])
{
int n=0;
char s[256];

 if (argc>1)
    cout<<argv[1]<<endl;
 else
    {
    printf("Not arguments");
    }

FILE *f = fopen(argv[1],"r");
   if(f==NULL)
      printf("Could not open file");
   else
      {
      while(!feof(f))
         {
         fscanf(f,"%s",s);
         n++;
         }
      fclose(f);
      printf("%d",n);
      }

 system("pause");
 return 0;
}
